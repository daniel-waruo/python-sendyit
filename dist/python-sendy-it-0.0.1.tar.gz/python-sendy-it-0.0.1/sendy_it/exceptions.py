class SendyAPIError(Exception):
    pass


class MissingAPICredentions(Exception):
    pass

